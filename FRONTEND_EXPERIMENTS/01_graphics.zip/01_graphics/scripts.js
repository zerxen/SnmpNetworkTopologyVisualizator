// ####################################
// # replaces content of specified DIV
// ####################################
function printToDivWithID(id,text){
  div = document.getElementById(id);
  div.innerHTML += text;
}

function cleanDivWithID(id){
  div = document.getElementById(id);
  div.innerHTML = "";
}

function OnClickLinkDetails(source_name, target_name, source_indexes, target_indexes ){

    console.log(source_name.id)
    console.log(source_indexes)
    console.log(target_name.id)
    console.log(target_indexes)

    cleanDivWithID("infobox")
    cleanDivWithID("infobox_header")

    printToDivWithID("infobox_header",source_name.id + " - " + target_name.id + "<br>")
    printToDivWithID("infobox_header","<img src=\"img/site/LeftPanelSeparation.png\">")

    targetdiv = document.getElementById("infobox")

    // # READING INTERFACE GRAPHS DATA
    // ###############################
    readTextFile("data/interface_stats.json", function(text){
        var data = JSON.parse(text);

        source_FoundMatch = 0;
        target_FoundMatch = 0;

        // # PRINTING ALL SOURCE GRAPHS:
        for (var key in data) {
            console.log("Key: " + key + " vs " + source_name.id);

            if ((source_name.id.localeCompare(key)) == 0){
                console.log("match!");
                source_FoundMatch = 1;

                for (var interface of data[source_name.id]['interfaces']){
                    console.log("interface:" + interface['index'] + " vs ")
                    console.log(source_indexes)
                    if (source_indexes.includes(interface['index'])){
                        console.log("found graph for " + source_name.id + " - " + interface['ifDescr'])

                        var iDivGraph = document.createElement('div');
                        iDivGraph.id = source_name.id + "_" + interface['ifDescr'] + "_graph";
                        targetdiv.appendChild(iDivGraph);
                        draw_device_interface_graphs_to_div(interface,source_name.id, data, targetdiv)
                    }
                }
            }
        }
        if (!(source_FoundMatch)){
            warning_text = "<br><h4>The link neighbor: ";
            warning_text+= source_name.id;
            warning_text+= " is not in database!</h4>";
            warning_text+= "This is most probably as you clicked on edge node ";
            warning_text+= "that is not SNMP data gathered, try clicking on its neighbors.";
            printToDivWithID("infobox",warning_text);
        }

        data = JSON.parse(text);
        // # PRINTING ALL TARGET GRAPHS:
        for (var key in data) {
            console.log("Key: " + key + " vs " + target_name.id);

            if ((target_name.id.localeCompare(key)) == 0){
                console.log("match!");
                target_FoundMatch = 1;

                for (var interface of data[target_name.id]['interfaces']){
                    console.log("interface:" + interface['index'] + " vs ")
                    console.log(target_indexes)
                    if (target_indexes.includes(interface['index'])){
                        console.log("found graph for " + target_name.id + " - " + interface['ifDescr'])

                        var iDivGraph = document.createElement('div');
                        iDivGraph.id = target_name.id + "_" + interface['ifDescr'] + "_graph";
                        targetdiv.appendChild(iDivGraph);
                        draw_device_interface_graphs_to_div(interface,target_name.id, data, targetdiv)
                    }
                }
            }
        }
        if (!(target_FoundMatch)){
            warning_text = "<br><h4>The link neighbor: ";
            warning_text+= target_name.id;
            warning_text+= " is not in database!</h4>";
            warning_text+= "This is most probably as you clicked on edge node ";
            warning_text+= "that is not SNMP data gathered, try clicking on its neighbors.";
            printToDivWithID("infobox",warning_text);
        }
    });



}

// ###################################
// # Graph Drawing Functions         #
// ###################################

// This draws a single specific interface to div
function draw_device_interface_graphs_to_div(interface,deviceid, data, targetdiv){
        console.log("Interface: ")
        console.log(interface)

        var iDiv = document.createElement('div');
        iDiv.id = deviceid + "_" + interface['ifDescr'] + "_graph_header";
        iDiv.align = 'left';
        iDiv.innerHTML = "<br>" + deviceid + " - " + interface['ifDescr'];
        targetdiv.appendChild(iDiv);

        var iDivGraph = document.createElement('div');
        iDivGraph.id = deviceid + "_" + interface['ifDescr'] + "_graph";
        targetdiv.appendChild(iDivGraph);

        //var TimeStampStrings = ["x2001", "x2002", "x2003", "x2004", "x2005", "x2006", "x2007", "x2008", "x2009", "x2010", "x2011", "x2013"]
        //var InOctetsData = [74, 82, 80, 74, 73, 72, 74, 70, 70, 66, 66, 69];
        //var OutOctetsData = [14, 8, 78, 74, 24, 2, 7, 40, 76, 100, 78, 12];
        var TimeStampStrings = []
        var InOctetsData = []
        var OutOctetsData = []

        for (var stats of interface['stats']){
            TimeStampStrings.push(stats['time'])
            InOctetsData.push(stats['InSpeed'])
            OutOctetsData.push(stats['OutSpeed'])
            console.log(TimeStampStrings)
            console.log(InOctetsData)
            console.log(OutOctetsData)
        }
        draw_graph_from_data_to_div(InOctetsData,OutOctetsData,TimeStampStrings,iDivGraph)
}

// This draws all interfaces from device to div
function draw_device_graphs_to_div(deviceid, data, targetdiv){

    for (var interface of data[deviceid]['interfaces']){
        draw_device_interface_graphs_to_div(interface,deviceid, data, targetdiv)
    }
}


function draw_graph_from_data_to_div(InOctetsData,OutOctetsData,TimeStampStrings,iDivGraph){


    traceOut = {
      type: 'scatter',
      x: TimeStampStrings,
      y: OutOctetsData,
      mode: 'lines',
      name: 'Out',
      line: {
        color: 'rgb(219, 64, 82)',
        width: 3
      }
    };

    traceIn = {
      type: 'scatter',
      x: TimeStampStrings,
      y: InOctetsData,
      mode: 'lines',
      name: 'In',
      line: {
        color: 'rgb(55, 128, 191)',
        width: 1
      }
    };

    var layout = {
      // title:'Adding Names to Line and Scatter Plot',
      margin: {
        autoexpand: true,
        l: 35,
        r: 20,
        t: 5,
        b: 35
      },
      width: 600,
      height: 150,
      xaxis: {
        title: 'Time',
        showgrid: true,
        zeroline: true,
        showline: true
      },
      yaxis: {
        title: 'Mbps',
        showline: true,
        showtickprefix: 'first'
      },
      paper_bgcolor: 'rgba(255,255,255,0.7)',
      plot_bgcolor: 'rgba(0,0,0,0)'
    };

    var data = [traceOut, traceIn];

    Plotly.newPlot(iDivGraph, data, layout, {showSendToCloud: false});

}