// ####################################
// # replaces content of specified DIV
// ####################################
function printToDivWithID(id,text){
  div = document.getElementById(id);
  div.innerHTML += text;
}

function cleanDivWithID(id){
  div = document.getElementById(id);
  div.innerHTML = "";
}

// ###################################
// # Graph for Link Drawing Functions#
// ###################################

function OnLinkClick(node_a, node_b){
    console.log("Logging from OnLinkClick")
    console.log(node_a)
    console.log(node_b)
}

// ###################################
// # Graph Drawing Functions         #
// ###################################

function draw_device_graphs_to_div(deviceid, data, targetdiv){

    for (var interface of data[deviceid]['interfaces']){

        console.log("Interface: ")
        console.log(interface)

        var iDiv = document.createElement('div');
        iDiv.id = deviceid + "_" + interface['ifDescr'] + "_graph_header";
        iDiv.align = 'left';
        iDiv.innerHTML = interface['ifDescr'];
        targetdiv.appendChild(iDiv);

        var iDivGraph = document.createElement('div');
        iDivGraph.id = deviceid + "_" + interface['ifDescr'] + "_graph";
        targetdiv.appendChild(iDivGraph);

        //var TimeStampStrings = ["x2001", "x2002", "x2003", "x2004", "x2005", "x2006", "x2007", "x2008", "x2009", "x2010", "x2011", "x2013"]
        //var InOctetsData = [74, 82, 80, 74, 73, 72, 74, 70, 70, 66, 66, 69];
        //var OutOctetsData = [14, 8, 78, 74, 24, 2, 7, 40, 76, 100, 78, 12];
        var TimeStampStrings = []
        var InOctetsData = []
        var OutOctetsData = []

        // This is to check if the stats is not empty
        if (interface['stats'].length != 0){
            for (var stats of interface['stats']){
                TimeStampStrings.push(stats['time'])
                InOctetsData.push(stats['InSpeed'])
                OutOctetsData.push(stats['OutSpeed'])
                console.log(TimeStampStrings)
                console.log(InOctetsData)
                console.log(OutOctetsData)
            }
            draw_graph_from_data_to_div(InOctetsData,OutOctetsData,TimeStampStrings,iDivGraph)
        }
    }
}


function draw_graph_from_data_to_div(InOctetsData,OutOctetsData,TimeStampStrings,iDivGraph){


    traceOut = {
      type: 'scatter',
      x: TimeStampStrings,
      y: OutOctetsData,
      mode: 'lines',
      name: 'Out',
      line: {
        color: 'rgb(219, 64, 82)',
        width: 3
      }
    };

    traceIn = {
      type: 'scatter',
      x: TimeStampStrings,
      y: InOctetsData,
      mode: 'lines',
      name: 'In',
      line: {
        color: 'rgb(55, 128, 191)',
        width: 1
      }
    };

    var layout = {
      // title:'Adding Names to Line and Scatter Plot',
      margin: {
        autoexpand: true,
        l: 35,
        r: 20,
        t: 5,
        b: 35
      },
      width: 600,
      height: 150,
      xaxis: {
        title: 'Time',
        showgrid: true,
        zeroline: true,
        showline: true
      },
      yaxis: {
        title: 'Mbps',
        showline: true,
        showtickprefix: 'first'
      },
      paper_bgcolor: 'rgba(255,255,255,0.7)',
      plot_bgcolor: 'rgba(0,0,0,0)'
    };

    var data = [traceOut, traceIn];

    Plotly.newPlot(iDivGraph, data, layout, {showSendToCloud: false});

}